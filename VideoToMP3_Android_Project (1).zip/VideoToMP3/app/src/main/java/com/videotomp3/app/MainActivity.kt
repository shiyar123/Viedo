package com.videotomp3.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.content.FileProvider
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var convertButton: Button
    private lateinit var pickButton: Button
    private lateinit var shareButton: Button
    private var selectedVideo: Uri? = null
    private var outputFile: File? = null

    private val purple = 0xFF5B46D6.toInt()
    private val ink = 0xFF202033.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF302477.toInt()
        window.navigationBarColor = 0xFFFFFFFF.toInt()
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(0xFFF7F6FC.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "Video to MP3"
            textSize = 28f
            setTextColor(purple)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 24, 0, 8)
        }
        val subtitle = TextView(this).apply {
            text = "حوّل الفيديو إلى صوت بسهولة"
            textSize = 17f
            setTextColor(ink)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 28)
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 28, 20, 28)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val icon = TextView(this).apply {
            text = "♫"
            textSize = 58f
            setTextColor(purple)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "اختر فيديو من هاتفك للبدء"
            textSize = 16f
            setTextColor(ink)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        pickButton = Button(this).apply {
            text = "اختيار فيديو"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(purple)
            setOnClickListener { chooseVideo() }
        }
        convertButton = Button(this).apply {
            text = "تحويل إلى MP3"
            isEnabled = false
            setOnClickListener { convertVideo() }
        }
        shareButton = Button(this).apply {
            text = "مشاركة الملف الصوتي"
            visibility = View.GONE
            setOnClickListener { shareAudio() }
        }
        card.addView(icon)
        card.addView(status)
        card.addView(pickButton, match())
        card.addView(convertButton, match())
        card.addView(shareButton, match())

        val note = TextView(this).apply {
            text = "• التحويل يتم على جهازك\n• صيغة الإخراج: MP3\n• لا حاجة إلى رفع الفيديو للإنترنت"
            textSize = 14f
            setTextColor(0xFF666477.toInt())
            setPadding(4, 24, 4, 0)
        }

        content.addView(title, match())
        content.addView(subtitle, match())
        content.addView(card, match())
        content.addView(note, match())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun match() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 12 }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, 100)
    }

    @Deprecated("Deprecated in Android API, retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            selectedVideo = data?.data
            if (selectedVideo != null) {
                status.text = "تم اختيار الفيديو بنجاح"
                convertButton.isEnabled = true
                shareButton.visibility = View.GONE
            }
        }
    }

    private fun convertVideo() {
        val uri = selectedVideo ?: return
        convertButton.isEnabled = false
        pickButton.isEnabled = false
        status.text = "جارٍ تجهيز الفيديو..."
        Thread {
            try {
                val input = File(cacheDir, "input_video_${System.currentTimeMillis()}.mp4")
                contentResolver.openInputStream(uri).use { source ->
                    requireNotNull(source) { "تعذر فتح الفيديو" }
                    FileOutputStream(input).use { dest -> source.copyTo(dest) }
                }
                val outDir = getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: filesDir
                val out = File(outDir, "Audio_${System.currentTimeMillis()}.mp3")
                val command = "-y -i \"${input.absolutePath}\" -vn -codec:a libmp3lame -q:a 2 \"${out.absolutePath}\""
                runOnUiThread { status.text = "جارٍ تحويل الفيديو إلى MP3..." }
                FFmpegKit.executeAsync(command) { session ->
                    val success = ReturnCode.isSuccess(session.returnCode)
                    runOnUiThread {
                        convertButton.isEnabled = true
                        pickButton.isEnabled = true
                        if (success && out.exists() && out.length() > 0) {
                            outputFile = out
                            status.text = "اكتمل التحويل بنجاح!\n${out.name}"
                            shareButton.visibility = View.VISIBLE
                            Toast.makeText(this, "تم حفظ الصوت داخل مجلد Music الخاص بالتطبيق", Toast.LENGTH_LONG).show()
                        } else {
                            status.text = "تعذر التحويل. جرّب فيديو آخر."
                            Toast.makeText(this, "فشل التحويل", Toast.LENGTH_LONG).show()
                        }
                        input.delete()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    convertButton.isEnabled = true
                    pickButton.isEnabled = true
                    status.text = "حدث خطأ أثناء قراءة الفيديو"
                }
            }
        }.start()
    }

    private fun shareAudio() {
        val file = outputFile ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "audio/mpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(share, "مشاركة ملف MP3"))
    }
}
